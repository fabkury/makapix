import { useState, useRef, useCallback } from "react";
import { Upload, X, AlertCircle, CheckCircle2 } from "lucide-react";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { Label } from "./components/ui/label";
import { Slider } from "./components/ui/slider";
import { RadioGroup, RadioGroupItem } from "./components/ui/radio-group";
import { Checkbox } from "./components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Switch } from "./components/ui/switch";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./components/ui/accordion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./components/ui/alert-dialog";

interface FileInfo {
  width: number;
  height: number;
  format: string;
  frames: number;
  frameDuration: number | null;
}

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Form inputs
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [postAsHidden, setPostAsHidden] = useState(false);
  const [allowEdit, setAllowEdit] = useState(true);
  const [scale, setScale] = useState(100);
  const [scaleAlgorithm, setScaleAlgorithm] = useState("NN");
  
  // Scaling state
  const [scalingMode, setScalingMode] = useState<"ratio" | "dimensions">("ratio");
  const [customWidth, setCustomWidth] = useState<string>("");
  const [customHeight, setCustomHeight] = useState<string>("");
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);
  const [previewScaling, setPreviewScaling] = useState(false);

  // Messages
  const [message, setMessage] = useState<{ type: "error" | "success" | "info"; text: string } | null>(null);
  const [showClearDialog, setShowClearDialog] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = useCallback(async (selectedFile: File) => {
    // Validate file type
    if (!selectedFile.type.startsWith("image/")) {
      setMessage({ type: "error", text: "File format not supported. Please upload an image file." });
      return;
    }

    setFile(selectedFile);
    setMessage(null);

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(selectedFile);

    // Extract file info
    const img = new Image();
    img.onload = () => {
      const info: FileInfo = {
        width: img.naturalWidth,
        height: img.naturalHeight,
        format: selectedFile.type.split("/")[1].toUpperCase(),
        frames: selectedFile.type === "image/gif" ? 1 : 1, // Simplified for static images
        frameDuration: null, // Would need GIF parser for actual frame duration
      };
      setFileInfo(info);
    };
    img.src = URL.createObjectURL(selectedFile);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);

      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile) {
        handleFileSelect(droppedFile);
      }
    },
    [handleFileSelect]
  );

  const handleFileInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const selectedFile = e.target.files?.[0];
      if (selectedFile) {
        handleFileSelect(selectedFile);
      }
    },
    [handleFileSelect]
  );

  const handleScaleChange = (value: number[]) => {
    setScale(value[0]);
  };

  const handleScaleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value >= 3.125 && value <= 300) {
      setScale(value);
    }
  };

  const handleWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setCustomWidth(value);
    
    if (fileInfo && value && maintainAspectRatio) {
      const numValue = parseInt(value);
      if (!isNaN(numValue) && numValue > 0) {
        const aspectRatio = fileInfo.width / fileInfo.height;
        const newHeight = Math.round(numValue / aspectRatio);
        setCustomHeight(newHeight.toString());
        
        // Update scale ratio
        const newScale = (numValue / fileInfo.width) * 100;
        setScale(Math.min(300, Math.max(3.125, newScale)));
      }
    }
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setCustomHeight(value);
    
    if (fileInfo && value && maintainAspectRatio) {
      const numValue = parseInt(value);
      if (!isNaN(numValue) && numValue > 0) {
        const aspectRatio = fileInfo.width / fileInfo.height;
        const newWidth = Math.round(numValue * aspectRatio);
        setCustomWidth(newWidth.toString());
        
        // Update scale ratio
        const newScale = (numValue / fileInfo.height) * 100;
        setScale(Math.min(300, Math.max(3.125, newScale)));
      }
    }
  };

  const handleClearAll = () => {
    setFile(null);
    setPreview("");
    setFileInfo(null);
    setTitle("");
    setDescription("");
    setHashtags("");
    setPostAsHidden(false);
    setAllowEdit(true);
    setScale(100);
    setScaleAlgorithm("NN");
    setMessage(null);
    setShowClearDialog(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = () => {
    if (!file) {
      setMessage({ type: "error", text: "Please upload an artwork before submitting." });
      return;
    }

    if (!title.trim()) {
      setMessage({ type: "error", text: "Please provide a title for your artwork." });
      return;
    }

    // Simulate successful upload
    setMessage({ type: "success", text: "File upload successful! Your artwork has been posted." });
  };

  const getResizedDimensions = () => {
    if (!fileInfo || scale === 100) return null;
    const ratio = scale / 100;
    return {
      width: Math.round(fileInfo.width * ratio),
      height: Math.round(fileInfo.height * ratio),
    };
  };

  const resizedDimensions = getResizedDimensions();

  return (
    <div className="min-h-screen bg-black text-white" style={{ fontFamily: "'Noto Sans', sans-serif" }}>
      <div className="container mx-auto px-4 py-6 md:py-10 max-w-6xl">
        {/* Header */}
        <div className="mb-8 md:mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-2" style={{ fontFamily: "'Noto Serif', serif" }}>
            Upload Artwork
          </h1>
          <div className="h-[2px] w-20 bg-gradient-to-r from-cyan-500 to-pink-500"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
          {/* Left Column - Upload and Preview */}
          <div className="space-y-6">
            {/* Upload Area */}
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`
                relative border-2 border-dashed rounded-lg p-8 md:p-12 cursor-pointer
                transition-all duration-200 hover:border-cyan-500
                ${isDragging ? "border-pink-500 bg-pink-500/10" : "border-white/30"}
                ${preview ? "min-h-[200px]" : "min-h-[250px] md:min-h-[300px]"}
              `}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileInputChange}
                className="hidden"
              />

              {preview ? (
                <div className="flex flex-col items-center space-y-4">
                  <img
                    src={preview}
                    alt="Preview"
                    style={
                      previewScaling && fileInfo
                        ? {
                            width: `${Math.round(fileInfo.width * scale / 100)}px`,
                            height: `${Math.round(fileInfo.height * scale / 100)}px`,
                            imageRendering: scaleAlgorithm === "NN" ? "pixelated" : "auto",
                          }
                        : undefined
                    }
                    className="max-w-full max-h-[400px] object-contain border border-white/20 rounded"
                  />
                  {previewScaling && (
                    <div className="text-xs text-pink-400 font-mono bg-pink-500/10 px-3 py-1 rounded border border-pink-500/30">
                      Scaled preview active
                    </div>
                  )}
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      setFile(null);
                      setPreview("");
                      setFileInfo(null);
                      setPreviewScaling(false);
                      if (fileInputRef.current) {
                        fileInputRef.current.value = "";
                      }
                    }}
                    variant="outline"
                    size="sm"
                    className="bg-black border-white/30 hover:bg-white/10 hover:border-pink-500"
                  >
                    <X className="mr-2 h-4 w-4" />
                    Remove
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center space-y-4 text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-pink-500 flex items-center justify-center">
                    <Upload className="w-8 h-8 text-black" />
                  </div>
                  <div>
                    <p className="text-lg font-semibold mb-1">Drop your artwork here</p>
                    <p className="text-sm text-white/60">or click to browse</p>
                  </div>
                </div>
              )}
            </div>

            {/* File Info */}
            {fileInfo && (
              <div className="border border-white/20 rounded-lg p-4 md:p-6 bg-white/5 space-y-3">
                <h3 className="font-semibold text-cyan-400 mb-4" style={{ fontFamily: "'Noto Serif', serif" }}>
                  Artwork Information
                </h3>
                
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-white/60 mb-1">Original Size</p>
                    <p className="font-mono text-white">{fileInfo.width} × {fileInfo.height} px</p>
                  </div>
                  
                  <div>
                    <p className="text-white/60 mb-1">Format</p>
                    <p className="font-mono text-white">{fileInfo.format}</p>
                  </div>
                  
                  <div>
                    <p className="text-white/60 mb-1">Animation Frames</p>
                    <p className="font-mono text-white">{fileInfo.frames}</p>
                  </div>
                  
                  <div>
                    <p className="text-white/60 mb-1">Frame Duration</p>
                    <p className="font-mono text-white">{fileInfo.frameDuration ? `${fileInfo.frameDuration}ms` : "N/A"}</p>
                  </div>
                  
                  {resizedDimensions && (
                    <>
                      <div className="col-span-2">
                        <p className="text-white/60 mb-1">Resized Size</p>
                        <p className="font-mono text-pink-400">{resizedDimensions.width} × {resizedDimensions.height} px</p>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Form Inputs */}
          <div className="space-y-6">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="text-white/80">Artwork Title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter artwork title..."
                className="bg-black border-white/30 focus:border-cyan-500 text-white placeholder:text-white/40"
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description" className="text-white/80">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your artwork..."
                rows={4}
                className="bg-black border-white/30 focus:border-cyan-500 text-white placeholder:text-white/40 resize-none"
              />
            </div>

            {/* Hashtags */}
            <div className="space-y-2">
              <Label htmlFor="hashtags" className="text-white/80">Hashtags</Label>
              <Input
                id="hashtags"
                value={hashtags}
                onChange={(e) => setHashtags(e.target.value)}
                placeholder="#art #digital #creative"
                className="bg-black border-white/30 focus:border-cyan-500 text-white placeholder:text-white/40"
              />
            </div>

            {/* Image Scaling - Accordion */}
            <Accordion type="single" collapsible className="border border-white/20 rounded-lg bg-white/5">
              <AccordionItem value="scaling" className="border-none">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-white/5">
                  <span className="text-cyan-400 font-semibold" style={{ fontFamily: "'Noto Serif', serif" }}>
                    Image Scaling
                  </span>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <Tabs defaultValue="ratio" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 bg-white/10">
                      <TabsTrigger 
                        value="ratio"
                        className="data-[state=active]:bg-cyan-500 data-[state=active]:text-black"
                      >
                        By Ratio
                      </TabsTrigger>
                      <TabsTrigger 
                        value="dimensions"
                        className="data-[state=active]:bg-cyan-500 data-[state=active]:text-black"
                      >
                        By Dimensions
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="ratio" className="space-y-4 mt-4">
                      <div className="flex items-center justify-between">
                        <Label className="text-white/80">Scaling Ratio</Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            value={scale}
                            onChange={handleScaleInputChange}
                            min={3.125}
                            max={300}
                            step={0.1}
                            className="w-28 h-8 text-center bg-black border-white/30 focus:border-pink-500 text-white font-mono text-sm"
                          />
                          <span className="text-white/60 text-sm">%</span>
                        </div>
                      </div>

                      {fileInfo && scale !== 100 && (
                        <div className="text-xs text-cyan-400 font-mono bg-cyan-500/10 p-3 rounded border border-cyan-500/30">
                          New size: {Math.round(fileInfo.width * scale / 100)} × {Math.round(fileInfo.height * scale / 100)} px
                        </div>
                      )}

                      {fileInfo && scale === 100 && (
                        <div className="text-xs text-white/60 font-mono bg-white/5 p-3 rounded border border-white/20">
                          Original size: {fileInfo.width} × {fileInfo.height} px (no scaling)
                        </div>
                      )}

                      {!fileInfo && (
                        <div className="text-xs text-white/40 font-mono bg-white/5 p-3 rounded border border-white/10">
                          Upload an image to see size information
                        </div>
                      )}

                      <p className="text-xs text-white/60 mt-2">
                        Valid range: 3.125% to 300%
                      </p>
                    </TabsContent>

                    <TabsContent value="dimensions" className="space-y-4 mt-4">
                      <div className="flex items-center justify-between mb-4">
                        <Label htmlFor="aspect-ratio-switch" className="text-white/80 text-sm">
                          Maintain aspect ratio
                        </Label>
                        <Switch
                          id="aspect-ratio-switch"
                          checked={maintainAspectRatio}
                          onCheckedChange={setMaintainAspectRatio}
                          className="data-[state=checked]:bg-cyan-500"
                        />
                      </div>

                      <p className="text-xs text-white/60 mb-4">
                        {maintainAspectRatio 
                          ? "Specify one dimension, the other will be calculated automatically to maintain aspect ratio" 
                          : "Specify both dimensions independently"}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="custom-width" className="text-white/80 text-sm">
                            Width (px)
                          </Label>
                          <Input
                            id="custom-width"
                            type="number"
                            value={customWidth}
                            onChange={handleWidthChange}
                            placeholder={fileInfo ? fileInfo.width.toString() : "Width"}
                            className="bg-black border-white/30 focus:border-cyan-500 text-white font-mono"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="custom-height" className="text-white/80 text-sm">
                            Height (px)
                          </Label>
                          <Input
                            id="custom-height"
                            type="number"
                            value={customHeight}
                            onChange={handleHeightChange}
                            placeholder={fileInfo ? fileInfo.height.toString() : "Height"}
                            className="bg-black border-white/30 focus:border-cyan-500 text-white font-mono"
                          />
                        </div>
                      </div>

                      {customWidth && customHeight && (
                        <div className="text-xs text-cyan-400 font-mono bg-cyan-500/10 p-3 rounded border border-cyan-500/30">
                          Output: {customWidth} × {customHeight} px ({scale.toFixed(2)}% of original)
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>

                  {/* Scaling Algorithm */}
                  <div className="space-y-3 mt-6 pt-4 border-t border-white/10">
                    <Label className="text-white/80">Scaling Algorithm</Label>
                    <RadioGroup value={scaleAlgorithm} onValueChange={setScaleAlgorithm}>
                      <div className="flex items-center space-x-3">
                        <RadioGroupItem
                          value="NN"
                          id="nn"
                          className="border-white/40 text-cyan-500"
                        />
                        <Label htmlFor="nn" className="text-sm cursor-pointer text-white/90 font-mono">
                          Nearest Neighbor (NN)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-3">
                        <RadioGroupItem
                          value="LZ3"
                          id="lz3"
                          className="border-white/40 text-cyan-500"
                        />
                        <Label htmlFor="lz3" className="text-sm cursor-pointer text-white/90 font-mono">
                          Lanczos3 (LZ3)
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Preview Scaling Button */}
                  {fileInfo && (
                    <div className="mt-4 pt-4 border-t border-white/10">
                      <Button
                        onClick={() => setPreviewScaling(!previewScaling)}
                        disabled={!file}
                        className={`w-full ${
                          previewScaling
                            ? "bg-pink-500 hover:bg-pink-600"
                            : "bg-gradient-to-r from-cyan-500 to-pink-500 hover:from-cyan-600 hover:to-pink-600"
                        } text-black font-semibold`}
                      >
                        {previewScaling ? "Reset Preview" : "Preview Scaling"}
                      </Button>
                      <p className="text-xs text-white/60 mt-2 text-center">
                        {previewScaling 
                          ? "Click to view original size" 
                          : "Click to preview scaled image"}
                      </p>
                    </div>
                  )}
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* Upload Options */}
            <div className="border border-white/20 rounded-lg p-4 md:p-6 bg-white/5 space-y-5">
              <h3 className="font-semibold text-pink-400 mb-4" style={{ fontFamily: "'Noto Serif', serif" }}>
                Upload Options
              </h3>

              {/* Checkboxes */}
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="hidden"
                    checked={postAsHidden}
                    onCheckedChange={(checked) => setPostAsHidden(checked as boolean)}
                    className="border-white/40 data-[state=checked]:bg-cyan-500 data-[state=checked]:border-cyan-500"
                  />
                  <Label htmlFor="hidden" className="text-sm cursor-pointer text-white/90">
                    Post as hidden
                  </Label>
                </div>

                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="allow-edit"
                    checked={allowEdit}
                    onCheckedChange={(checked) => setAllowEdit(checked as boolean)}
                    className="border-white/40 data-[state=checked]:bg-cyan-500 data-[state=checked]:border-cyan-500"
                  />
                  <Label htmlFor="allow-edit" className="text-sm cursor-pointer text-white/90">
                    Allow others to edit
                  </Label>
                </div>
              </div>
            </div>

            {/* Messages */}
            {message && (
              <div
                className={`
                  flex items-start space-x-3 p-4 rounded-lg border
                  ${message.type === "error" ? "bg-red-500/10 border-red-500/50" : ""}
                  ${message.type === "success" ? "bg-green-500/10 border-green-500/50" : ""}
                  ${message.type === "info" ? "bg-cyan-500/10 border-cyan-500/50" : ""}
                `}
              >
                {message.type === "error" && <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />}
                {message.type === "success" && <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />}
                {message.type === "info" && <AlertCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />}
                <p className="text-sm text-white/90">{message.text}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <Button
                onClick={handleSubmit}
                className="flex-1 bg-gradient-to-r from-cyan-500 to-pink-500 hover:from-cyan-600 hover:to-pink-600 text-black font-semibold"
              >
                Submit
              </Button>
              <Button
                onClick={() => setShowClearDialog(true)}
                variant="outline"
                className="flex-1 sm:flex-none border-white/30 hover:bg-white/10 hover:border-red-500 text-white"
              >
                Clear All
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Clear Confirmation Dialog */}
      <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <AlertDialogContent className="bg-black border border-white/30 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white" style={{ fontFamily: "'Noto Serif', serif" }}>
              Clear all fields?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-white/70">
              This action will remove all your inputs including the uploaded artwork. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent border-white/30 text-white hover:bg-white/10">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleClearAll}
              className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white"
            >
              Clear All
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}