
  # Artwork Upload Interface

  This is a code bundle for Artwork Upload Interface. The original project is available at https://www.figma.com/design/kAVcfA5mnirOvXSQJovXr6/Artwork-Upload-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  