
  # Mobile User Profile Page

  This is a code bundle for Mobile User Profile Page. The original project is available at https://www.figma.com/design/B3ujaFg8w4okxIT0dunyuT/Mobile-User-Profile-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  