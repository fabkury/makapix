
  # Design Floating Button Menu

  This is a code bundle for Design Floating Button Menu. The original project is available at https://www.figma.com/design/fPlUq09ondXZUNEguGpUSK/Design-Floating-Button-Menu.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  